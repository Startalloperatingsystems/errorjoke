using System;
using System.Diagnostics.Eventing.Reader;
using System.Windows.Forms;
namespace errorwunwinx_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            if (MessageBox.Show("are you sure", "Last message", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes);
            {
                Errorsmartscreen errorsmartscreen = new Errorsmartscreen();
                errorsmartscreen.Show();
            }

          
        }
    }
}
